# CHEAT ONOFRE — Android

Projeto inicial de app Android com interface gamer escura e detalhes neon.

## O que inclui
- Tela inicial CHEAT ONOFRE
- Cartões de ferramentas e caixas informativas
- Dicas gerais de desempenho e treino

Este protótipo é independente do Free Fire: não inclui cheats, manipulação de memória, bypass de anti-cheat ou automação do jogo.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `Cheat_Onofre` no Android Studio.
3. Aguarde a sincronização do Gradle e instale os componentes solicitados.
4. Use **Build > Build APK(s)**.
5. O APK de debug costuma aparecer em `app/build/outputs/apk/debug/app-debug.apk`.

Requer Android Studio com suporte ao Android Gradle Plugin 8.7.3 e SDK 35.
