package com.exus.cheatonofre;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9, 11, 16);
    private final int CARD = Color.rgb(20, 24, 33);
    private final int NEON = Color.rgb(0, 245, 160);
    private final int WHITE = Color.rgb(240, 244, 248);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(28));
        scroll.addView(root);

        TextView tag = text("EXUS • ANDROID GAMING", 12, NEON, true);
        root.addView(tag);
        TextView title = text("CHEAT ONOFRE", 30, WHITE, true);
        title.setPadding(0, dp(8), 0, dp(3));
        root.addView(title);
        TextView sub = text("PAINEL GAMER  /  VERSÃO 1.0", 12, Color.LTGRAY, false);
        root.addView(sub);

        LinearLayout status = card();
        TextView st = text("●  SISTEMA PRONTO", 14, NEON, true);
        status.addView(st);
        TextView description = text("Painel independente para ajustes e diagnóstico. Não altera o Free Fire nem contorna o anti-cheat.", 14, WHITE, false);
        description.setPadding(0, dp(10), 0, 0);
        status.addView(description);
        root.addView(status, marginParams(0, 22, 0, 0));

        root.addView(section("FERRAMENTAS"));
        addAction(root, "Diagnóstico do aparelho", "Verifique informações básicas e dicas de desempenho.", "DICAS DE DESEMPENHO", "• Feche apps que não estiver usando.\n• Mantenha espaço livre no armazenamento.\n• Evite jogar enquanto o aparelho estiver muito quente.\n• Use uma conexão estável.");
        addAction(root, "Treino de mira", "Abrir um lembrete para praticar em ambiente de treino.", "TREINO", "Pratique rastreamento, precisão e controle de sensibilidade no modo de treino do próprio jogo.");
        addAction(root, "Configurações do painel", "Informações da versão e do projeto.", "SOBRE", "CHEAT ONOFRE • versão 1.0\nPainel visual independente para Android.");
        TextView footer = text("FEITO PARA ANDROID  •  EXUS", 11, Color.GRAY, true);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(26), 0, dp(4));
        root.addView(footer);

        setContentView(scroll);
    }

    private void addAction(LinearLayout root, String title, String subtitle, String dialogTitle, String message) {
        LinearLayout box = card();
        box.setFocusable(true);
        TextView t = text(title, 17, WHITE, true);
        box.addView(t);
        TextView s = text(subtitle, 13, Color.LTGRAY, false);
        s.setPadding(0, dp(6), 0, dp(14));
        box.addView(s);
        TextView button = text("ABRIR  →", 13, BG, true);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(14), dp(10), dp(14), dp(10));
        button.setBackground(round(NEON, 10));
        box.addView(button, new LinearLayout.LayoutParams(-1, -2));
        View.OnClickListener click = v -> new android.app.AlertDialog.Builder(this)
                .setTitle(dialogTitle).setMessage(message)
                .setPositiveButton("ENTENDI", (d, w) -> d.dismiss()).show();
        button.setOnClickListener(click);
        box.setOnClickListener(click);
        root.addView(box, marginParams(0, 12, 0, 0));
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        l.setBackground(round(CARD, 16));
        return l;
    }
    private TextView section(String s) {
        TextView t = text(s, 12, NEON, true);
        t.setPadding(0, dp(24), 0, dp(2));
        return t;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private LinearLayout.LayoutParams marginParams(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(l), dp(t), dp(r), dp(b)); return p;
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
